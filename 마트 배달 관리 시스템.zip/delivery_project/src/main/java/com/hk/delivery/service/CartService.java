package com.hk.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.delivery.daos.ICartDao;
import com.hk.delivery.dtos.CartDto;

@Service
public class CartService implements ICartService{

	@Autowired
	private ICartDao cartDao;

	@Override
	public boolean insertCart(CartDto cartDto) {
		return cartDao.insertCart(cartDto);
	}

	@Override
	public List<CartDto> getCartList(String id) {
		return cartDao.getCartList(id);
	}

	@Override
	public List<CartDto> selectCartSeq(String id) {
		return cartDao.selectCartSeq(id);
	}

	@Override
	public List<CartDto> selectSeqsList(int[] chks) {
		return cartDao.selectSeqsList(chks);
	}

	@Override
	public boolean deleteCart(String id, String[] cart_seqs,String[] goods_seqs) {
		return cartDao.deleteCart(id,cart_seqs,goods_seqs);
	}

	@Override
	public boolean updateAddr(String id, String cart_seq, String lat, String lng) {
		return cartDao.updateAddr(id,cart_seq,lat,lng);
	}

	@Override
	public List<CartDto> selectchk(String id) {
		return cartDao.selectchk(id);
	}

	@Override
	public CartDto selectMap(String user_id) {
		return cartDao.selectMap(user_id);
	}

}
