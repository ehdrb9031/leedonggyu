package com.hk.delivery;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.hk.delivery.daos.GoodsDao;
import com.hk.delivery.dtos.CartDto;
import com.hk.delivery.dtos.FileBoardDto;
import com.hk.delivery.dtos.GoodsDto;
import com.hk.delivery.dtos.OrderDto;
import com.hk.delivery.dtos.UserDto;
import com.hk.delivery.service.ICartService;
import com.hk.delivery.service.IFileBoardService;
import com.hk.delivery.service.IGoodsService;
import com.hk.delivery.service.IOrderService;
import com.hk.delivery.service.IUserService;
import com.hk.utils.Util;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private ICartService cartService;
	@Autowired
	private IGoodsService goodsService;
	@Autowired
	private IOrderService orderService;
	@Autowired
	private IUserService userService;
	@Autowired
	private IFileBoardService fileboardService;

	@RequestMapping(value = "/home.do", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate );

		return "home";
	}

	//-------------------------------�α���-------------------------------

	@RequestMapping(value = "/login.do")
	public String login(HttpServletRequest request,@RequestParam("id")String id, @RequestParam("password")String password,Locale locale, Model model) {
		logger.info("�α��� {}.", locale);

		String page=null;
		UserDto ldto=userService.getLogin(id, password);

		if(ldto==null||ldto.getId()==null) {
			model.addAttribute("msg", "�α��� �����Դϴ�. ���̵�, �佺���带 Ȯ���ϼ���" );
			page="error/error";
		}else {
			request.getSession().setAttribute("ldto", ldto);
			request.getSession().setMaxInactiveInterval(10*60);
			if(ldto.getRole().toUpperCase().equals("ADMIN")) {
				page="admin_main";
			}else if(ldto.getRole().toUpperCase().equals("USER")) {
				page="user_main";
			}else if(ldto.getRole().toUpperCase().equals("MART")) {
				page="mart_main";
			}else if(ldto.getRole().toUpperCase().equals("RIDER")) {
				page="redirect:rider_main.do";
			}
		}
		return page;
	}

	@RequestMapping(value = "/logout.do")
	public String logout(HttpServletRequest request, Locale locale, Model model) {
		logger.info("�α׾ƿ� {}.", locale);

		request.getSession().invalidate();
		return "redirect:index.jsp";
	}

	@RequestMapping(value = "/back.do")
	public String back(@RequestParam("id") String id, @RequestParam("pw") String password, Locale locale, Model model) {
		logger.info("�ڷΰ��� {}.", locale);
		UserDto ldto=userService.getLogin(id, password);

		String page=null;

		if(ldto.getRole().toUpperCase().equals("ADMIN")) {
			page="admin_main";
		}else if(ldto.getRole().toUpperCase().equals("USER")) {
			page="user_main";
		}else if(ldto.getRole().toUpperCase().equals("MART")) {
			page="mart_main";
		}else if(ldto.getRole().toUpperCase().equals("RIDER")) {
			page="rider_main";
		}
		return page;
	}

	@RequestMapping(value = "/registform.do")
	public String registForm(Locale locale, Model model) {
		logger.info("ȸ������ �� �̵� {}.", locale);

		return "registform";
	}

	@RequestMapping(value = "/after_regist.do", method = RequestMethod.POST)
	public String after_regist(@RequestParam("id")String id,@RequestParam("pw")String password,@RequestParam("name")String name,
			@RequestParam("address")String address,@RequestParam("phone")String phone,@RequestParam("email")String email,
			@RequestParam("role")String role,Locale locale, Model model) {
		logger.info("ȸ������ {}.", locale);
		boolean isS = userService.insertUser(
				new UserDto(id,name,password,address,phone,email,role,null,null)
				);
		if(isS) {
			return "redirect:index.jsp";			
		}else {
			model.addAttribute("msg", "ȸ������ ����" );
			return "error/error";
		}
	}

	@RequestMapping(value = "/idchk.do", method = RequestMethod.GET)
	public String idchk(@RequestParam("id")String id,Locale locale, Model model) {
		logger.info("���̵� �ߺ� ��ȸ {}.", locale);

		String resultId=userService.idChk(id);
		String isS="y";//��뿩�θ� ��Ÿ���� isS ����(y�� ��밡��, n�� ������)
		if(resultId!=null){//id�� �ߺ��Ǹ�
			isS="n";
		}

		model.addAttribute("isS", isS);
		return "idchk";
	}

	//-------------------------------�α��� ��-------------------------------

	//-------------------------------������-------------------------------

	@RequestMapping(value = "/goodslist.do")
	public String goods_manage(HttpServletRequest request, Locale locale, Model model) {
		logger.info("��ǰ ���� �� �̵� {}.", locale);

		List<GoodsDto>gList=goodsService.getGoodsList();
		//		List<FileBoardDto> fList=fileboardService.getFileList();		
		List<FileBoardDto> fList=fileboardService.getFileList();

		model.addAttribute("gList", gList);
		model.addAttribute("fList", fList);

		return "goodslist";
	}



	//-------------------------------������ ��-------------------------------

	//-------------------------------��Ʈ-------------------------------
	@RequestMapping(value = "/addgoods.do")
	public String addgoods(HttpServletRequest request, Locale locale, Model model) {
		logger.info("��ǰ ��� �� �̵� {}.", locale);

		return "addgoods";
	}

	@RequestMapping(value = "/insertgoods.do")
	public String insertgoods(HttpServletRequest request, GoodsDto dto, Locale locale, Model model) {
		logger.info("��ǰ ��� {}.", locale);

		boolean gisS=goodsService.insertgoods(dto);
		if(gisS) {
			boolean fisS=fileboardService.multiInsertFileInfo(request);
			if(fisS) {
				return "redirect:goodslist.do";				
			}else {
				model.addAttribute("msg", "�̹��� ��� ����" );
				return "error/error";		
			}
		}else{
			model.addAttribute("msg", "��ǰ��� ����" );
			return "error/error";		
		}
	}

	@RequestMapping(value = "/goods_muldel.do")
	public String mulDel(Locale locale, Model model,@RequestParam("chk") String[] seqs) {
		logger.info("��ǰ �����ϱ� {}.", locale);
		System.out.println("seq:"+seqs[0]);
		boolean fisS=fileboardService.deleteFile(seqs);
		if(fisS) {
			boolean gisS=goodsService.deleteGoods(seqs);
			if(gisS) {
				return "redirect:goodslist.do";
			}else {
				model.addAttribute("msg", "��ǰ��������");
				return "error";
			}	
		}else {
			model.addAttribute("msg", "��ǰ���� ����" );
			return "error/error";	
		}
	}


	//�ֹ����� ������ �̵�
	@RequestMapping(value = "/mart_order.do")
	public String mart_order(Locale locale, Model model) {
		logger.info("�ֹ����� ������ �̵� {}.", locale);
		
		List<OrderDto>oList=orderService.selectOrderList();
		model.addAttribute("oList", oList);
		
		return "mart_order";
	}
	
	@RequestMapping(value = "/order_state.do")
	public String order_state(Locale locale, Model model,@RequestParam("order_seq") int order_seq) {
		logger.info("�ֹ����� ������ �̵� {}.", locale);
		
		boolean isS=orderService.updateMartState(order_seq);
		if(isS) {
			return "redirect:mart_order.do";
		}else {
			model.addAttribute("msg", "��ۻ��� ������Ʈ ����" );
			return "error/error";	
		}
		
	}
	
	//-------------------------------��Ʈ ��-------------------------------


	//-------------------------------����-------------------------------
	@RequestMapping(value = "/searchgoods.do")
	public String searchgoods(@RequestParam("search")String search, Locale locale, Model model) {
		logger.info("��ǰ �˻� {}.", locale);
		System.out.println("search"+search);
		List<GoodsDto>gList=goodsService.selectGoodsList(search);
		int [] seqs=new int[gList.size()];
		for (int i = 0; i < gList.size(); i++) {
			GoodsDto dto=gList.get(i);
			seqs[i]=dto.getGoods_seq();
		}
		
		List<FileBoardDto> fList=fileboardService.getSearchList(seqs);

		model.addAttribute("gList", gList);
		model.addAttribute("fList", fList);

		return "searchgoodslist";
	}
	
	@RequestMapping(value = "/goodsdetail.do")
	public String goodsdetail(@RequestParam("seq")String seq, Locale locale, Model model) {
		logger.info("��ǰ �󼼺��� {}.", locale);
		
		 GoodsDto gDto = goodsService.goodsdetail(seq);
		 List<FileBoardDto> fList = fileboardService.filedetail(seq);
		 System.out.println("size:" + fList.size());
		 model.addAttribute("gDto", gDto);
		 model.addAttribute("fList", fList);

		 return "goodsdetail";
	}

	@RequestMapping(value = "/btnsearch.do")
	public String btnsearch(@RequestParam("cate") String category, Locale locale, Model model) {
		logger.info("ī�װ��� ��ư Ŭ�� {}.", locale);

		List<GoodsDto> gList=goodsService.selectCateList(category);
		List<String>sSeq=goodsService.selectCateSeq(category);
		int [] seqs=new int[sSeq.size()];
		for (int i = 0; i < sSeq.size(); i++) {
			GoodsDto dto=gList.get(i);
			seqs[i]=dto.getGoods_seq();
		}

		List<FileBoardDto> fList=fileboardService.getSearchList(seqs);
		model.addAttribute("gList", gList);
		model.addAttribute("fList", fList);
		model.addAttribute("category", category);
		return "category";
	}

	@RequestMapping(value = "/goods_basket.do")
	public String goods_basket(@RequestParam("seq") int seq,@RequestParam("id") String id,
			@RequestParam("count") int count,Locale locale, Model model) {
		logger.info("��ٱ��� ��� {}.", locale);

		
		boolean isS = cartService.insertCart(new CartDto(0,id,seq,count));
		if (isS) {
			List<CartDto>cList=cartService.getCartList(id);
			int [] gSeqs=new int[cList.size()];
			
			for (int i = 0; i < cList.size(); i++) {
				CartDto cDto=cList.get(i);
				gSeqs[i]=cDto.getGoods_seq();
			} 
			List<FileBoardDto> fList=fileboardService.getSearchList(gSeqs);
			List<GoodsDto>gList=goodsService.selectSeqsList(gSeqs);			
			model.addAttribute("gList", gList);
			model.addAttribute("fList", fList);
			model.addAttribute("cList",cList);
			return "mybasket";
		} else {
			return "error/error";
		}
	}

	@RequestMapping(value = "/mybasket.do")
	public String mybasket(@RequestParam("id") String id, Locale locale, Model model) {
		logger.info("��ٱ��� ��ȸ {}.", locale);

		List<CartDto>cList=cartService.getCartList(id);
		
		int [] gSeqs=new int[cList.size()];
		
		for (int i = 0; i < cList.size(); i++) {
			CartDto cDto=cList.get(i);
			gSeqs[i]=cDto.getGoods_seq();
		} 

		List<FileBoardDto> fList=fileboardService.getSearchList(gSeqs);
		List<GoodsDto>gList=goodsService.selectSeqsList(gSeqs);			

		model.addAttribute("gList", gList);
		model.addAttribute("fList", fList);
		model.addAttribute("cList",cList);
		
		return "mybasket";
	}
	
	@RequestMapping(value = "/searchAddr.do")
	public String searchAddr(Locale locale, Model model,@RequestParam("cart_seq") String cart_seq
			) {
		logger.info("����� �˻� {}.", locale);

		model.addAttribute("cart_seq", cart_seq);
		return "searchAddr";
	}	
	
	@RequestMapping(value = "/after_addr.do")
	public String after_addr(Locale locale, Model model,@RequestParam("cart_seq") String cart_seq
			,@RequestParam("id") String id,@RequestParam("lng") String lng
			,@RequestParam("lat") String lat) {
		logger.info("����� �˻� {}.", locale);
		System.out.println(id+cart_seq+lat+lng);
		boolean isS=cartService.updateAddr(id,cart_seq,lat,lng);
		if(isS) {
			List<CartDto>cList=cartService.selectchk(id);
			int[] chk=new int[cList.size()];
			for (int i = 0; i < cList.size(); i++) {
				CartDto dto=cList.get(i);
				chk[i]=dto.getGoods_seq();
			}
			return "redirect:orders.do?chk="+chk[0];			
		}else {
			model.addAttribute("msg", "����� �˻� ����" );
			return "error/error";	
		}
	}	
	
	
	
	//----------------
	//�����ȸ Ŭ�� �� ���� �浵 order_seq ������ user_map�� �ѷ��ֱ�

	@RequestMapping(value = "/user_map.do")
	public String user_map(@RequestParam("user_id") String user_id, @RequestParam("order_seq") String order_seq, Locale locale, Model model) {
		logger.info("user_map {}.", locale);

		OrderDto oDto=orderService.selectSeq(order_seq);
		CartDto cDto=cartService.selectMap(user_id);
		
		model.addAttribute("oDto", oDto);
		model.addAttribute("cDto", cDto);
		
		return "user_map";
	}	

	//-------------------------------���� ��-------------------------------
	
	//-------------------------------����-------------------------------
	@RequestMapping(value = "/orders.do")
	public String orders(Locale locale, Model model, @RequestParam("chk") int[] chks) {
		logger.info("orders ������ �̵�{}.", locale);
		
		List<GoodsDto>gList=goodsService.selectSeqsList(chks);
		List<FileBoardDto>fList=fileboardService.getSearchList(chks);
		List<CartDto>cList=cartService.selectSeqsList(chks);
		
		
		int [] gSeqs=new int[cList.size()];
		
		for (int i = 0; i < cList.size(); i++) {
			CartDto cDto=cList.get(i);
			gSeqs[i]=cDto.getGoods_seq();
		} 
			
		model.addAttribute("gList", gList);
		model.addAttribute("fList", fList);
		model.addAttribute("cList",cList);
		
		return "orders";
	}
	
	
	@RequestMapping(value = "/payment.do")
	public String payment(Locale locale, Model model,@RequestParam("goods_seq") String[] goods_seq
			,@RequestParam("cart_seq") String[] cart_seq,@RequestParam("order_count") String[] order_count
			,@RequestParam("goods_name") String[] goods_name, @RequestParam("order_addr") String order_addr,
			@RequestParam("order_comment") String order_comment, @RequestParam("orders_price") String orders_price
			) {
		logger.info("����â �̵� {}.", locale);
		
		String goods=goods_name[0];

		String sumName=Util.sumName(goods_name);
		String cartSeq=Util.sumName(cart_seq);
		String orderCount=Util.sumName(order_count);
		String goodsSeq=Util.sumName(goods_seq);
		
		model.addAttribute("goods", goods);
		model.addAttribute("count", goods_name.length-1);
		model.addAttribute("price", orders_price);
		model.addAttribute("order_addr", order_addr);
		model.addAttribute("order_comment", order_comment);
		model.addAttribute("order_goods", sumName);
		model.addAttribute("cartSeq", cartSeq);
		model.addAttribute("order_count", orderCount);
		model.addAttribute("goods_seq", goodsSeq);
		
		return "payment";
	}
	
	@RequestMapping(value = "/insertpay.do")
	public String insertpay(Locale locale, Model model,@RequestParam("id") String id,
			@RequestParam("order_addr") String order_addr,@RequestParam("order_goods") String order_goods,
			@RequestParam("order_price") int order_price, @RequestParam("order_tel") String order_tel,
			@RequestParam("order_comment") String order_comment,@RequestParam("goods_seq") String goods_seq
			,@RequestParam("cartSeq") String cartSeq,@RequestParam("order_count") String order_count
			) {
		logger.info("���� ���� �� pay���̺� ���� {}.", locale);
		System.out.println(cartSeq);
		System.out.println(order_count);
		boolean oIsS=orderService.insertorder(new OrderDto(id,order_price,order_goods,order_tel,order_addr,order_comment,order_count));
		if(oIsS) {	
			String cart_seqs[]=cartSeq.split(",");
			String goods_seqs[]=goods_seq.split(",");
			for (int i = 0; i < cart_seqs.length; i++) {
				System.out.println(cart_seqs[i]);				
			}
			boolean cIsS=cartService.deleteCart(id,cart_seqs,goods_seqs);
			
			System.out.println("��������");
			return "redirect:after_order_result.do?id="+id;
		}else {
			model.addAttribute("msg", "���� ����" );
			return "error/error";	
		}	
	}
	
	@RequestMapping(value = "/after_order_result.do")
	public String insertpay(Locale locale, Model model,@RequestParam("id") String id) {
		logger.info("���� ������ �̵� {}.", locale);
		
		List<OrderDto>oList=orderService.selectOrderList(id);
		
		model.addAttribute("oList", oList);
		
		return "order_result";		
	}
	
	

	
	//-------------------------------���� ��-------------------------------
	
	//-------------------------------���̴�-------------------------------

	//���̴� ������ �̵�
	@RequestMapping(value = "/rider_main.do")
	public String rider_main(Locale locale, Model model) {
		logger.info("���̴� ������ �̵� {}.", locale);
		
		List<OrderDto>oList=orderService.selectMartList();
		model.addAttribute("oList", oList);
		
		return "rider_main";
	}
	
	//���̴� ��� ����
	@RequestMapping(value = "/rider_state.do")
	public String rider_state(Locale locale, Model model,@RequestParam("order_seq") int order_seq
			,@RequestParam("rider_id") String rider_id) {
		logger.info("���̴� ��� ���� {}.", locale);
		
		boolean isS=orderService.updateRiderState(order_seq);
		if(isS) {
			model.addAttribute("rider_id", rider_id);
			model.addAttribute("order_seq", order_seq);
			return "rider_map";
		}else {
			model.addAttribute("msg", "��ۻ��� ������Ʈ ����" );
			return "error/error";	
		}
		
	}
	
	@RequestMapping(value = "/rider_map.do")
	public String map(Locale locale, Model model,@RequestParam("rider_id") String rider_id
			,@RequestParam("order_seq") String order_seq) {
		logger.info("map ������ �̵� {}.", locale);
		
		model.addAttribute("rider_id", rider_id);
		model.addAttribute("order_seq", order_seq);
		return "rider_map";		
	}
	
	@RequestMapping(value = "/traking.do")
	public String traking(Locale locale, Model model, @RequestParam("lat") String lat,@RequestParam("lng") String lng
			,@RequestParam("rider_id") String rider_id,@RequestParam("order_seq") String order_seq) {
		logger.info("��� ���� �� ��ġ���� {}.", locale);
		
		System.out.println(lat+":"+lng);
		System.out.println(rider_id+":"+order_seq);
		boolean isS=orderService.updateMap(order_seq,rider_id,lat,lng);
		if(isS) {
			return "rider_map";					
		}else {
			model.addAttribute("msg", "�����ġ ������Ʈ ����" );
			return "error/error";	
		}
	}
	//-------------------------------���̴� ��-------------------------------
	
	//-------------------------------����-------------------------------
	@RequestMapping(value = "/error404.do", method = RequestMethod.GET)
	public String error404(Locale locale, Model model) {
		logger.info("404 ����{}.", locale);
		model.addAttribute("code", "404����");
		return "error/404";
	}

	@RequestMapping(value = "/error500.do", method = RequestMethod.GET)
	public String error500(Locale locale, Model model) {
		logger.info("500 ����{}.", locale);
		model.addAttribute("code", "500����");
		return "error/500";
	}
	
	@RequestMapping(value = "/build.do", method = RequestMethod.GET)
	public String build(Locale locale, Model model) {
		
		return "build";
	}
	
	//-------------------------------���� ��-------------------------------
}
