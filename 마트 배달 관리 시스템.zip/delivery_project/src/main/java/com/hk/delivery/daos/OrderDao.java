package com.hk.delivery.daos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.delivery.dtos.OrderDto;

@Repository
public class OrderDao implements IOrderDao{

	private String namespace="com.hk.order.";
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public boolean insertorder(OrderDto orderDto) {
		int count=sqlSessionTemplate.insert(namespace+"insertorder", orderDto);
		return count>0?true:false;
	}

	@Override
	public List<OrderDto> selectOrderList(String id) {
		return sqlSessionTemplate.selectList(namespace+"selectOrderList",id);
	}

	@Override
	public List<OrderDto> selectOrderList() {
		return sqlSessionTemplate.selectList(namespace+"stateOrderList");
	}

	@Override
	public boolean updateMartState(int order_seq) {
		int count=sqlSessionTemplate.update(namespace+"updateMartState", order_seq);
		return count>0?true:false;
	}

	@Override
	public List<OrderDto> selectMartList() {
		return sqlSessionTemplate.selectList(namespace+"selectMartList");
	}

	@Override
	public boolean updateRiderState(int order_seq) {
		int count=sqlSessionTemplate.update(namespace+"updateRiderState", order_seq);
		return count>0?true:false;
	}

	@Override
	public boolean updateMap(String order_seq, String rider_id, String lat, String lng) {
		Map<String, String>map=new HashMap<String, String>();
		map.put("order_seq", order_seq);
		map.put("rider_id", rider_id);
		map.put("order_lat", lat);
		map.put("order_lng", lng);
		int count=sqlSessionTemplate.update(namespace+"updateMap", map);
		return count>0?true:false;
	}

	@Override
	public OrderDto selectSeq(String order_seq) {
		return sqlSessionTemplate.selectOne(namespace+"selectSeq",order_seq);
	}
}
