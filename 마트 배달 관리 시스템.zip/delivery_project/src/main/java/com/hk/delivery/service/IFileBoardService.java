package com.hk.delivery.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.hk.delivery.dtos.FileBoardDto;

public interface IFileBoardService {
	public boolean multiInsertFileInfo(HttpServletRequest request,int seq);

	public boolean multiInsertFileInfo(HttpServletRequest request);

	public FileBoardDto getFileInfo(int seq);

	public List<FileBoardDto> getFileList();

	public boolean deleteFile(String[] seqs);

	public List<FileBoardDto> getSearchList(int[] seqs);

	public List<FileBoardDto> filedetail(String seq);
}
