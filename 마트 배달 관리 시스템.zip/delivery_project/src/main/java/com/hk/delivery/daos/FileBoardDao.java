package com.hk.delivery.daos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.delivery.dtos.FileBoardDto;

@Repository
public class FileBoardDao implements IFileBoardDao{
	
	private String namespace="com.hk.file.";
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public boolean insertFileInfo(FileBoardDto dto) {
		int count=sqlSessionTemplate.insert(namespace+"insertFileInfo",dto);
		return count>0?true:false;
	}

	@Override
	public FileBoardDto getFileInfo(int seq) {
		Map<String, Integer>map=new HashMap<String, Integer>();
		map.put("seq", seq);
		return sqlSessionTemplate.selectOne(namespace+"getFileList", map);
	}

	@Override
	public List<FileBoardDto> getFileList() {
		return sqlSessionTemplate.selectList(namespace+"getFileList");
	}

	@Override
	public boolean deleteFile(String[] seqs) {
		Map<String, String[]>map=new HashMap<String, String[]>();
		map.put("seqs", seqs);
		System.out.println("map:"+seqs[0]);
		int count=sqlSessionTemplate.delete(namespace+"deleteFile", map);
		return count>0?true:false;
	}

	@Override
	public List<FileBoardDto> getSearchList(int[] seqs) {
		Map<String, int[]>map=new HashMap<String, int[]>();
		map.put("seqs", seqs);
		return sqlSessionTemplate.selectList(namespace+"getSearchList",map);
	}

	@Override
	public List<FileBoardDto> filedetail(String seq) {
		return sqlSessionTemplate.selectList(namespace+"filedetail",seq);
	}

}
