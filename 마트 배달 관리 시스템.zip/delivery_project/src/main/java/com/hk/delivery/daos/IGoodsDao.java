package com.hk.delivery.daos;

import java.util.List;

import com.hk.delivery.dtos.GoodsDto;

public interface IGoodsDao {

	public boolean insertgoods(GoodsDto dto);

	public int selectseq(String goods_name);

	public List<GoodsDto> getGoodsList();

	public List<GoodsDto> selectGoodsList(String search);

	public boolean deleteGoods(String[] seqs);

	public List<GoodsDto> selectCateList(String category);

	public List<String> selectCateSeq(String category);

	public List<GoodsDto> selectSeqsList(int[] seqs);

	public GoodsDto goodsdetail(String seq);

	public List<GoodsDto> selectOrderList(String[] order_goods);
	
}
