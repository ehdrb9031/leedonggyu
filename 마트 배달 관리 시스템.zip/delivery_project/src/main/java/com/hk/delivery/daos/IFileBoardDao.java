package com.hk.delivery.daos;

import java.util.List;

import com.hk.delivery.dtos.FileBoardDto;
import com.hk.delivery.dtos.GoodsDto;

public interface IFileBoardDao {
	public boolean insertFileInfo(FileBoardDto dto);

	public FileBoardDto getFileInfo(int seq);

	public List<FileBoardDto> getFileList();

	public boolean deleteFile(String[] seqs);

	public List<FileBoardDto> getSearchList(int[] seqs);

	public List<FileBoardDto> filedetail(String seq);
}
