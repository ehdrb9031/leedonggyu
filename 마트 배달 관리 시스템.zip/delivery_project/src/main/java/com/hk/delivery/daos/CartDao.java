package com.hk.delivery.daos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.delivery.dtos.CartDto;

@Repository
public class CartDao implements ICartDao {

	private String namespace="com.hk.cart.";
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public boolean insertCart(CartDto dto) {
		int count=sqlSessionTemplate.insert(namespace+"insertCart", dto);
		return count>0?true:false;
	}

	@Override
	public List<CartDto> getCartList(String id) {
		return sqlSessionTemplate.selectList(namespace+"getcartlist",id);
	}

	@Override
	public List<CartDto> selectCartSeq(String id) {
		return sqlSessionTemplate.selectList(namespace+"selectCartSeq", id);
	}

	@Override
	public List<CartDto> selectSeqsList(int[] seqs) {
		Map<String, int[]>map=new HashMap<String, int[]>();
		map.put("seqs", seqs);
		return sqlSessionTemplate.selectList(namespace+"selectSeqsList", map);
	}

	@Override
	public boolean deleteCart(String id, String[] cart_seqs, String[] goods_seqs) {
		String[] ids= {id};
		Map<String, String[]>map=new HashMap<String, String[]>();
		map.put("ids", ids);
		map.put("cart_seqs", cart_seqs);
		map.put("goods_seqs", goods_seqs);
		int count=sqlSessionTemplate.delete(namespace+"deleteCart",map);
		return count>0?true:false;
	}

	@Override
	public boolean updateAddr(String id, String cart_seq, String lat, String lng) {
		Map<String, String>map=new HashMap<String, String>();
		map.put("user_id", id);
		map.put("cart_seq", cart_seq);
		map.put("user_lat", lat);
		map.put("user_lng", lng);
		int count=sqlSessionTemplate.update(namespace+"updateAddr",map);
		return count>0?true:false;
	}

	@Override
	public List<CartDto> selectchk(String user_id) {
		return sqlSessionTemplate.selectList(namespace+"selectchk",user_id);
	}

	@Override
	public CartDto selectMap(String user_id) {
		return sqlSessionTemplate.selectOne(namespace+"selectMap",user_id);
	}

}
