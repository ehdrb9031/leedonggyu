package com.hk.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.delivery.daos.IOrderDao;
import com.hk.delivery.dtos.OrderDto;

@Service
public class OrderService implements IOrderService{

	@Autowired
	private IOrderDao orderDao;

	@Override
	public boolean insertorder(OrderDto orderDto) {
		return orderDao.insertorder(orderDto);
	}

	@Override
	public List<OrderDto> selectOrderList(String id) {
		return orderDao.selectOrderList(id);
	}

	@Override
	public List<OrderDto> selectOrderList() {
		return orderDao.selectOrderList();
	}

	@Override
	public boolean updateMartState(int order_seq) {
		return orderDao.updateMartState(order_seq);
	}

	@Override
	public List<OrderDto> selectMartList() {
		return orderDao.selectMartList();
	}

	@Override
	public boolean updateRiderState(int order_seq) {
		return orderDao.updateRiderState(order_seq);
	}

	@Override
	public boolean updateMap(String order_seq, String rider_id, String lat, String lng) {
		return orderDao.updateMap(order_seq,rider_id,lat,lng);
	}

	@Override
	public OrderDto selectSeq(String order_seq) {
		return orderDao.selectSeq(order_seq);
	}
}
