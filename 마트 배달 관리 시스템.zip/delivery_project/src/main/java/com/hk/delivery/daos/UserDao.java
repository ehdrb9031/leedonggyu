package com.hk.delivery.daos;

import java.util.HashMap;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.delivery.dtos.UserDto;

@Repository
public class UserDao implements IUserDao{

	private String namespace="com.hk.user.";
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public UserDto getLogin(String id, String password) {
		Map<String, String>map=new HashMap<String, String>();
		map.put("id", id);
		map.put("password", password);
		return sqlSessionTemplate.selectOne(namespace+"getLogin",map);
	}

	@Override
	public boolean insertUser(UserDto userDto) {
		int count=0;
		count=sqlSessionTemplate.insert(namespace+"insertUser", userDto);
		return count>0?true:false;
	}

	@Override
	public String idChk(String id) {
		return sqlSessionTemplate.selectOne(namespace+"idChk", id);
	}

}
