package com.hk.delivery.service;

import com.hk.delivery.dtos.UserDto;

public interface IUserService {

    public UserDto getLogin(String id, String password);

	public boolean insertUser(UserDto userDto);

	public String idChk(String id);

}
