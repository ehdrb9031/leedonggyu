package com.hk.delivery.dtos;

import java.util.Date;

public class FileBoardDto {
	
	private int goods_seq;
	private String origin_fname;
	private String stored_fname;
	private int file_size;
	private Date regdate;
	private String f_delflag;
	public FileBoardDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public FileBoardDto(int goods_seq) {
		super();
		this.goods_seq = goods_seq;
	}

	public FileBoardDto(int goods_seq, String origin_fname, String stored_fname, int file_size, Date regdate,
			String f_delflag) {
		super();
		this.goods_seq = goods_seq;
		this.origin_fname = origin_fname;
		this.stored_fname = stored_fname;
		this.file_size = file_size;
		this.regdate = regdate;
		this.f_delflag = f_delflag;
	}
	public int getGoods_seq() {
		return goods_seq;
	}
	public void setGoods_seq(int goods_seq) {
		this.goods_seq = goods_seq;
	}
	public String getOrigin_fname() {
		return origin_fname;
	}
	public void setOrigin_fname(String origin_fname) {
		this.origin_fname = origin_fname;
	}
	public String getStored_fname() {
		return stored_fname;
	}
	public void setStored_fname(String stored_fname) {
		this.stored_fname = stored_fname;
	}
	public int getFile_size() {
		return file_size;
	}
	public void setFile_size(int file_size) {
		this.file_size = file_size;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public String getF_delflag() {
		return f_delflag;
	}
	public void setF_delflag(String f_delflag) {
		this.f_delflag = f_delflag;
	}
	@Override
	public String toString() {
		return "FileBoardDto [goods_seq=" + goods_seq + ", origin_fname=" + origin_fname + ", stored_fname="
				+ stored_fname + ", file_size=" + file_size + ", regdate=" + regdate + ", f_delflag=" + f_delflag + "]";
	}
	
	
}
