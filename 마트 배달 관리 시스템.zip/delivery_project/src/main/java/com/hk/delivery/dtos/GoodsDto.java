package com.hk.delivery.dtos;

import java.util.Date;

public class GoodsDto {
	
	private int goods_seq;
	private String goods_name;
	private String goods_category;
	private String goods_comment;
	private int goods_star;
	private String goods_weight;
	private int goods_count;
	private int goods_price;
	private Date g_regdate;
	

	public GoodsDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public GoodsDto(int goods_seq, String goods_name, String goods_category, String goods_comment, int goods_star,
			String goods_weight, int goods_count, int goods_price) {
		super();
		this.goods_seq = goods_seq;
		this.goods_name = goods_name;
		this.goods_category = goods_category;
		this.goods_comment = goods_comment;
		this.goods_star = goods_star;
		this.goods_weight = goods_weight;
		this.goods_count = goods_count;
		this.goods_price = goods_price;
	}
	
	public GoodsDto(int goods_seq, String goods_name, String goods_category, String goods_comment, int goods_star,
			String goods_weight, int goods_count, int goods_price, Date g_regdate) {
		super();
		this.goods_seq = goods_seq;
		this.goods_name = goods_name;
		this.goods_category = goods_category;
		this.goods_comment = goods_comment;
		this.goods_star = goods_star;
		this.goods_weight = goods_weight;
		this.goods_count = goods_count;
		this.goods_price = goods_price;
		this.g_regdate = g_regdate;
	}

	public Date getG_regdate() {
		return g_regdate;
	}
	
	public void setG_regdate(Date g_regdate) {
		this.g_regdate = g_regdate;
	}

	public int getGoods_price() {
		return goods_price;
	}

	public void setGoods_price(int goods_price) {
		this.goods_price = goods_price;
	}

	public int getGoods_seq() {
		return goods_seq;
	}

	public void setGoods_seq(int goods_seq) {
		this.goods_seq = goods_seq;
	}

	public String getGoods_name() {
		return goods_name;
	}

	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}

	public String getGoods_category() {
		return goods_category;
	}

	public void setGoods_category(String goods_category) {
		this.goods_category = goods_category;
	}

	public String getGoods_comment() {
		return goods_comment;
	}

	public void setGoods_comment(String goods_comment) {
		this.goods_comment = goods_comment;
	}

	public int getGoods_star() {
		return goods_star;
	}

	public void setGoods_star(int goods_star) {
		this.goods_star = goods_star;
	}

	public String getGoods_weight() {
		return goods_weight;
	}

	public void setGoods_weight(String goods_weight) {
		this.goods_weight = goods_weight;
	}

	public int getGoods_count() {
		return goods_count;
	}

	public void setGoods_count(int goods_count) {
		this.goods_count = goods_count;
	}

	@Override
	public String toString() {
		return "GoodsDto [goods_seq=" + goods_seq + ", goods_name=" + goods_name + ", goods_category=" + goods_category
				+ ", goods_comment=" + goods_comment + ", goods_star=" + goods_star
				+ ", goods_weight=" + goods_weight + ", goods_count=" + goods_count + ", goods_price=" + goods_price
				+ "]";
	}
	
	
}
