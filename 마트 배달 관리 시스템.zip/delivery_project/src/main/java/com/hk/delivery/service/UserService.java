package com.hk.delivery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hk.delivery.daos.IUserDao;
import com.hk.delivery.dtos.UserDto;

@Service
public class UserService implements IUserService{

	@Autowired
	private IUserDao userDao;
	
	@Override
	public UserDto getLogin(String id, String password) {
		return userDao.getLogin(id, password);
	}

	@Override
	public boolean insertUser(UserDto userDto) {
		return userDao.insertUser(userDto);
	}

	@Override
	public String idChk(String id) {
		return userDao.idChk(id);
	}

	
}
