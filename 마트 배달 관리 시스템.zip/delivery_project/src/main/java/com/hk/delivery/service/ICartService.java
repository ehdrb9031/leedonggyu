package com.hk.delivery.service;

import java.util.List;

import com.hk.delivery.dtos.CartDto;

public interface ICartService {

	public boolean insertCart(CartDto cartDto);

	public List<CartDto> getCartList(String id);

	public List<CartDto> selectCartSeq(String id);

	public List<CartDto> selectSeqsList(int[] chks);

	public boolean deleteCart(String id, String[] cart_seqs, String[] goods_seqs);

	public boolean updateAddr(String id, String cart_seq, String lat, String lng);

	public List<CartDto> selectchk(String id);

	public CartDto selectMap(String user_id);

}
