package com.hk.delivery.daos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hk.delivery.dtos.GoodsDto;

@Repository
public class GoodsDao implements IGoodsDao{
	private String namespace="com.hk.goods.";
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	@Override
	public boolean insertgoods(GoodsDto dto) {
		int count=0;
		count=sqlSessionTemplate.insert(namespace+"insertgoods", dto);
		return count>0?true:false;
	}

	@Override
	public int selectseq(String goods_name) {
		return sqlSessionTemplate.selectOne(namespace+"selectseq", goods_name);
	}

	@Override
	public List<GoodsDto> getGoodsList() {
		return sqlSessionTemplate.selectList(namespace+"getGoodsList");
	}

	@Override
	public List<GoodsDto> selectGoodsList(String search) {
		return sqlSessionTemplate.selectList(namespace+"selectGoodsList", search);
	}

	@Override
	public boolean deleteGoods(String[] seqs) {
		Map<String, String[]>map=new HashMap<String, String[]>();
		map.put("seqs", seqs);
		System.out.println("map:"+seqs[0]);
		int count=sqlSessionTemplate.delete(namespace+"deleteGoods", map);
		return count>0?true:false;
	}

	@Override
	public List<GoodsDto> selectCateList(String category) {
		return sqlSessionTemplate.selectList(namespace+"selectCateList", category);
	}

	@Override
	public List<String> selectCateSeq(String category) {
		return sqlSessionTemplate.selectList(namespace+"selectCateSeq", category);
	}

	@Override
	public List<GoodsDto> selectSeqsList(int[] seqs) {
		Map<String, int[]>map=new HashMap<String, int[]>();
		map.put("seqs", seqs);
		return sqlSessionTemplate.selectList(namespace+"selectSeqsList", map);
	}

	@Override
	public GoodsDto goodsdetail(String seq) {
		return sqlSessionTemplate.selectOne(namespace+"goodsdetail", seq);
	}

	@Override
	public List<GoodsDto> selectOrderList(String[] goods_name) {
		Map<String, String[]>map=new HashMap<String, String[]>();
		map.put("goods_name", goods_name);
		return sqlSessionTemplate.selectList(namespace+"selectOrderList", map);
	}
	
}
