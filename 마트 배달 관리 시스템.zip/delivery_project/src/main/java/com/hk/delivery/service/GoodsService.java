package com.hk.delivery.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.hk.delivery.daos.GoodsDao;
import com.hk.delivery.daos.IGoodsDao;
import com.hk.delivery.dtos.GoodsDto;

@Service
public class GoodsService implements IGoodsService{

	@Autowired
	private IGoodsDao goodsDao;

	@Override
	public boolean insertgoods(GoodsDto dto) {
		return goodsDao.insertgoods(dto);
	}

	@Override
	public int selectseq(String goods_name) {
		return goodsDao.selectseq(goods_name);
	}

	@Override
	public List<GoodsDto> getGoodsList() {
		return goodsDao.getGoodsList();
	}

	@Override
	public List<GoodsDto> selectGoodsList(String search) {
		return goodsDao.selectGoodsList(search);
	}

	@Override
	public boolean deleteGoods(String[] seqs) {
		return goodsDao.deleteGoods(seqs);
	}

	@Override
	public List<GoodsDto> selectCateList(String category) {
		return goodsDao.selectCateList(category);
	}

	@Override
	public List<String> selectCateSeq(String category) {
		return goodsDao.selectCateSeq(category);
	}

	@Override
	public List<GoodsDto> selectSeqsList(int[] seqs) {
		if(seqs.length==0) {
			return null;
		}else {
			return goodsDao.selectSeqsList(seqs);			
		}
	}

	@Override
	public GoodsDto goodsdetail(String seq) {
		return goodsDao.goodsdetail(seq);
	}

	@Override
	public List<GoodsDto> selectOrderList(String[] order_goods) {
		return goodsDao.selectOrderList(order_goods);
	}
	
	

}
