package com.hk.delivery.daos;

import org.springframework.transaction.annotation.Transactional;

import com.hk.delivery.dtos.UserDto;

public interface IUserDao {

	@Transactional
	public UserDto getLogin(String id, String password);

	public boolean insertUser(UserDto userDto);

	public String idChk(String id);
}
