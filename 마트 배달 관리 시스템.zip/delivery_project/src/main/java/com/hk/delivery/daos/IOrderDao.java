package com.hk.delivery.daos;

import java.util.List;

import com.hk.delivery.dtos.OrderDto;

public interface IOrderDao {

	public boolean insertorder(OrderDto orderDto);

	public List<OrderDto> selectOrderList(String id);

	public List<OrderDto> selectOrderList();

	public boolean updateMartState(int order_seq);

	public List<OrderDto> selectMartList();

	public boolean updateRiderState(int order_seq);

	public boolean updateMap(String order_seq, String rider_id, String lat, String lng);

	public OrderDto selectSeq(String order_seq);

}
