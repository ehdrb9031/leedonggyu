package com.hk.delivery.daos;

import java.util.List;

import com.hk.delivery.dtos.CartDto;

public interface ICartDao {

	boolean insertCart(CartDto cartDto);

	List<CartDto> getCartList(String id);

	List<CartDto> selectCartSeq(String id);

	List<CartDto> selectSeqsList(int[] chks);

	boolean deleteCart(String id, String[] cart_seqs, String[] goods_seqs);

	boolean updateAddr(String id, String cart_seq, String lat, String lng);

	List<CartDto> selectchk(String id);

	CartDto selectMap(String user_id);

}
