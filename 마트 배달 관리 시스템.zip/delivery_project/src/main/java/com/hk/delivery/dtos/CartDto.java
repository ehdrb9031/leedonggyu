package com.hk.delivery.dtos;

import java.util.List;

public class CartDto {
	
	private int cart_seq;
	private String user_id;
	private int goods_seq;
	private int cart_count;
	private String user_lat;
	private String user_lng;
	


	public CartDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CartDto(String user_id, int goods_seq, int cart_count) {
		super();
		this.user_id = user_id;
		this.goods_seq = goods_seq;
		this.cart_count = cart_count;
	}

	public CartDto(int cart_seq, String user_id, int goods_seq, int cart_count) {
		super();
		this.cart_seq = cart_seq;
		this.user_id = user_id;
		this.goods_seq = goods_seq;
		this.cart_count = cart_count;
	}
	
	public String getUser_lat() {
		return user_lat;
	}

	public void setUser_lat(String user_lat) {
		this.user_lat = user_lat;
	}

	public String getUser_lng() {
		return user_lng;
	}

	public void setUser_lng(String user_lng) {
		this.user_lng = user_lng;
	}

	public int getCart_seq() {
		return cart_seq;
	}

	public void setCart_seq(int cart_seq) {
		this.cart_seq = cart_seq;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public int getGoods_seq() {
		return goods_seq;
	}

	public void setGoods_seq(int goods_seq) {
		this.goods_seq = goods_seq;
	}

	public int getCart_count() {
		return cart_count;
	}

	public void setCart_count(int cart_count) {
		this.cart_count = cart_count;
	}

	@Override
	public String toString() {
		return "CartDto [cart_seq=" + cart_seq + ", user_id=" + user_id + ", goods_seq=" + goods_seq + ", cart_count="
				+ cart_count + "]";
	}
	
	
}
